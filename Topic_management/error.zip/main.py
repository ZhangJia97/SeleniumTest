from selenium import webdriver
from time import sleep

# 判断页面中某个元素是否存在
def is_element_exist(css):
    s = driver.find_element_by_css_selector(css_selector=css).text
    if s:
        return True
    else:
        return False

# 连接浏览器并打开主页
driver = webdriver.Chrome()
url = 'https://c.njupt.edu.cn/test/'
driver.get(url)

# 更改浏览器cookie做到免登录
cookies = [
    {'name': 'sessionid', 'value': '7aaft1vr5qcs2l96gd856sdd0964lqt8'},
    {'name': 'csrftoken', 'value': 'SXjCbgG2rHFZpuPqrqkhHbwpCOY1o9RM'},
]
driver.delete_all_cookies()
for cookie in cookies:
    driver.add_cookie(cookie)
driver.get(url)

# 正式测试
driver.find_element_by_class_name('dcjq-parent-li').click()
driver.find_element_by_id('extend_problem_list').click()
driver.find_element_by_id('tiankong_list').click()
driver.find_element_by_xpath('//*[@id="main-content"]/section/div/div/div/div[1]/a').click()
driver.find_element_by_xpath('//*[@id="problem-form"]/button[1]').click()
driver.find_element_by_css_selector('#input-43').send_keys('/Users/zhangjia/Downloads/test.zip')
sleep(1)
driver.find_element_by_css_selector('#myModal > div > div > div.modal-body > div.file-input > div.input-group.file-caption-main > div.input-group-btn > a').click()
sleep(2)
# color=driver.find_element_by_css_selector('#myModal > div > div > div.modal-body > div.file-input.has-error > div.input-group.file-caption-main > div.form-control.file-caption.kv-fileinput-caption').get_attribute('border-color').text
js="var elem = document.getElementsByClassName('form-control file-caption  kv-fileinput-caption');var color=elem.style.border-color;consolo.log(color)"
# print(color)
driver.execute_script(js)
driver.find_element_by_css_selector('#close')
driver.find_element_by_xpath('//*[@id="problem-form"]/button[2]').click()
errors=[]
if is_element_exist('#problem-form > div:nth-child(3) > span'):
    errors.append(driver.find_element_by_css_selector('#problem-form > div:nth-child(3) > span').text)
if is_element_exist('#problem-form > div:nth-child(8) > span'):
    errors.append(driver.find_element_by_css_selector('#problem-form > div:nth-child(8) > span').text)
if is_element_exist('#problem-form > div:nth-child(4) > div > input[type="text"]')==False:
    errors.append("请选择知识点")
for error in errors:
    print(error)